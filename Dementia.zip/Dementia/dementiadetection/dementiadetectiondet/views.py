from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
import pandas as pd
import pickle
from sklearn.neighbors import KNeighborsClassifier

# Create your views here.
def view_function(request):
	return HttpResponse("<h1>myveryfirst app</h1>")

def pred_view(request):
	temp = loader.get_template("dementiadetectiondet/index.html")
	model = pickle.load(open('C:\\Users\\ADMIN\\Dementia\\dementiadetection\\dementiadetectiondet\\templates\\dementiadetectiondet\\dementia_predictor.pkl', 'rb'))
	if request.method == "POST":
		mridelay  = request.POST['mridelay']
		gender    = request.POST['gender']
		age       = request.POST['age']
		educ      = request.POST['educ']
		ses       = request.POST['ses']
		mmse      = request.POST['mmse']
		cdr       = request.POST['cdr']
		

		input_variables = pd.DataFrame([[mridelay, gender, age, educ, ses, mmse, cdr]], columns=['MR Delay', 'M/F', 'Age', 'EDUC', 'SES', 'MMSE', 'CDR'], dtype=float)
		prediction = model.predict(input_variables)[0]

		
		args= {
			"prediction" : prediction
		}
		
		return HttpResponse(temp.render(args, request))
	else:
		return HttpResponse(temp.render({}, request))




