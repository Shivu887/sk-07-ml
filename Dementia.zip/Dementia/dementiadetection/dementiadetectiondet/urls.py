from django.urls import path, include
from . import views

urlpatterns = [
    path('indexpage/', views.pred_view, name="indexpage")
    ]
